import { Component } from '@angular/core';
import { CardComponent } from '../../components/card/card.component';
import { DataService } from '../../services/data.service';
import { Result } from '../../models/response.interface';
import { Sprites } from '../../models/response.interfacePokemon';
import { ResponsePokemon } from '../../models/response.interface';

@Component({
  selector: 'app-pokemon',
  standalone: true,
  imports: [CardComponent],
  templateUrl: './pokemon.component.html',
  styleUrl: './pokemon.component.css'
})
export class PokemonComponent {
  public constructor(public service: DataService) { }

  public url: string = 'https://pokeapi.co/api/v2/pokemon/';
  public pokemons: Result[] = [];
  public sprites: Sprites[] = [];
  public nextPage: null | string = '';
  public prevPage: null | string = '';


  public getPokemons(url: string): void {
    this.service.getResponse(url).subscribe(response => {
      this.pokemons = response.results;
      this.nextPage = response.next;
      this.prevPage = response.previous;
    });
  }

  public getPokemon(): void {
    this.pokemons.map((element => {
      this.service.getResponsePokemon(element.url).subscribe(response => {
        this.sprites.push(response.sprites);
      });
      console.log(this.sprites);
    }))
  }

  public changePage(i: number): void {
    if (i === 1) {
      if (this.nextPage !== null) {
        this.getPokemons(this.nextPage);
      }
    }
    else {
      if (this.prevPage !== null) {
        this.getPokemons(this.prevPage);
      }
    }
  }
  public onClick(i: number): void {

  }

  ngOnInit() {
    this.getPokemons(this.url);
    this.getPokemon();
  }
}
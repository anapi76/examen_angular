import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink,RouterLinkActive],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  public titles:string[] = ['Ejercicio1','Ejercicio2'];
  public titlesChange:string[]=['Pokemon','Rick & Morty'];
  public routes:string[]=['/pokemon','/rickandmorty'];
  public title1:string='';
  public title2:string='';

  public changeTitle(event:MouseEvent, i:number):void{
    const title:HTMLElement = <HTMLElement>event.target;
    if(event.type === 'mouseover'){
     this.title1=this.titlesChange[i];
    }
    else{
      this.title1=this.titles[i];
    }
  }

  

}
